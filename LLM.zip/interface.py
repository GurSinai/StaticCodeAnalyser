

class StaticCodeAnylazer():
    def scan_file(path, output_path):
        """ This Method will output to out file the SCA result """
        pass

    def split_output(path):
        """ 
        This Method will split the output to different errors 
        in a JSON format
        """
        pass

    def get_name():
        pass